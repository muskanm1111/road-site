

function ImgAbout() {
  return (
    <div className="bg-yellow-50 py-16">
      <h2 className="text-5xl font-bold text-center text-yellow-500 mb-8 ">
        About Us
      </h2>
      <div className="flex flex-wrap justify-start">
        <img src="https://design1-lime.vercel.app/_next/image?url=https%3A%2F%2Fdmt55mxnkgbz2.cloudfront.net%2F1205x0_s3-57820-MNSW-171_22-LP-1_jpeg.jpg&w=640&q=75" className="rounded-lg mx-auto"/>
        <div className="w-full md:w-1/3  bg-white shadow-lg rounded-lg p-6 text-center mx-20">
          <h3 className="text-xl font-semibold text-gray-800 mb-2">
            Building Infrastructure, Connecting Industries
          </h3>
          <p className="text-gray-600">
            As leaders in road construction machinery and services, we provide
            cutting-edge solutions for large-scale infrastructure projects. Our
            commitment to quality and innovation ensures optimal results for
            every client. 30+ years of industry experience State-of-the-art
            equipment Comprehensive maintenance services Expert team of
            professionals
          </p>
        </div>
      </div>
    </div>
  );
}

export default ImgAbout;